from django.contrib import messages
from django.shortcuts import render
import requests
from subprocess import run, PIPE
import sys
from django.shortcuts import render, redirect
from .forms import UserRegisterForm, GenerateGraphForm
from django.http import JsonResponse
from web.models import student



def ajax_generate_graph(request):
    if request.method == 'POST':
        data ={'data':request.POST['graph_type']}
        graph_type = request.POST['graph_type']
        independent_variable =request.POST['independent_variable']
        dependent_variable =request.POST['dependent_variable']
        dependent_extra_variable =request.POST['independent_variable_extra']
        colour_value = request.POST['colours']


        independent_values =['2008','2009','2010','2011','2012','2013','2014','2015','2016','2017','2018']
        dependent_values =[]
        dependent_values_1 = []
        if dependent_variable == 'RegistrationStart':
            y2008 = student.objects.filter(RegistrationStart='2008').count()
            dependent_values.append(y2008)
            y2009 = student.objects.filter(RegistrationStart='2009').count()
            dependent_values.append(y2009)
            y2010 = student.objects.filter(RegistrationStart='2010').count()
            dependent_values.append(y2010)
            y2011 = student.objects.filter(RegistrationStart='2011').count()
            dependent_values.append(y2011)
            y2012 = student.objects.filter(RegistrationStart='2012').count()
            dependent_values.append(y2012)
            y2013 = student.objects.filter(RegistrationStart='2013').count()
            dependent_values.append(y2013)
            y2014 = student.objects.filter(RegistrationStart='2014').count()
            dependent_values.append(y2014)
            y2015 = student.objects.filter(RegistrationStart='2015').count()
            dependent_values.append(y2015)
            y2016 = student.objects.filter(RegistrationStart='2016').count()
            dependent_values.append(y2016)
            y2017 = student.objects.filter(RegistrationStart='2017').count()
            dependent_values.append(y2017)
            y2018 = student.objects.filter(RegistrationStart='2018').count()
            dependent_values.append(y2018)
        elif dependent_variable == 'RegistrationEnd':
            y2008 = student.objects.filter(RegistrationEnd='2008').count()
            dependent_values.append(y2008)
            y2009 = student.objects.filter(RegistrationEnd='2009').count()
            dependent_values.append(y2009)
            y2010 = student.objects.filter(RegistrationEnd='2010').count()
            dependent_values.append(y2010)
            y2011 = student.objects.filter(RegistrationEnd='2011').count()
            dependent_values.append(y2011)
            y2012 = student.objects.filter(RegistrationEnd='2012').count()
            dependent_values.append(y2012)
            y2013 = student.objects.filter(RegistrationEnd='2013').count()
            dependent_values.append(y2013)
            y2014 = student.objects.filter(RegistrationEnd='2014').count()
            dependent_values.append(y2014)
            y2015 = student.objects.filter(RegistrationEnd='2015').count()
            dependent_values.append(y2015)
            y2016 = student.objects.filter(RegistrationEnd='2016').count()
            dependent_values.append(y2016)
            y2017 = student.objects.filter(RegistrationEnd='2017').count()
            dependent_values.append(y2017)
            y2018 = student.objects.filter(RegistrationEnd='2018').count()
            dependent_values.append(y2018)

        elif dependent_variable == 'YearStarted':
            y2008 = student.objects.filter(YearStarted='2008').count()
            dependent_values.append(y2008)
            y2009 = student.objects.filter(YearStarted='2009').count()
            dependent_values.append(y2009)
            y2010 = student.objects.filter(YearStarted='2010').count()
            dependent_values.append(y2010)
            y2011 = student.objects.filter(YearStarted='2011').count()
            dependent_values.append(y2011)
            y2012 = student.objects.filter(YearStarted='2012').count()
            dependent_values.append(y2012)
            y2013 = student.objects.filter(YearStarted='2013').count()
            dependent_values.append(y2013)
            y2014 = student.objects.filter(YearStarted='2014').count()
            dependent_values.append(y2014)
            y2015 = student.objects.filter(YearStarted='2015').count()
            dependent_values.append(y2015)
            y2016 = student.objects.filter(YearStarted='2016').count()
            dependent_values.append(y2016)
            y2017 = student.objects.filter(YearStarted='2017').count()
            dependent_values.append(y2017)
            y2018 = student.objects.filter(YearStarted='2018').count()
            dependent_values.append(y2018)





        elif dependent_extra_variable == 'RegistrationStart':
            y2008 = student.objects.filter(RegistrationStart='2008').count()
            dependent_values_1.append(y2008)

            y2009 = student.objects.filter(RegistrationStart='2009').count()
            dependent_values_1.append(y2009)

            y2010 = student.objects.filter(RegistrationStart='2010').count()
            dependent_values_1.append(y2010)

            y2011 = student.objects.filter(RegistrationStart='2011').count()
            dependent_values_1.append(y2011)

            y2012 = student.objects.filter(RegistrationStart='2012').count()
            dependent_values_1.append(y2012)

            y2013 = student.objects.filter(RegistrationStart='2013').count()
            dependent_values_1.append(y2013)

            y2014 = student.objects.filter(RegistrationStart='2014').count()
            dependent_values_1.append(y2014)

            y2015 = student.objects.filter(RegistrationStart='2015').count()
            dependent_values_1.append(y2015)

            y2016 = student.objects.filter(RegistrationStart='2016').count()
            dependent_values_1.append(y2016)

            y2017 = student.objects.filter(RegistrationStart='2017').count()
            dependent_values_1.append(y2017)

            y2018 = student.objects.filter(RegistrationStart='2018').count()
            dependent_values_1.append(y2018)

        elif dependent_extra_variable == 'RegistrationEnd':
            y2008 = student.objects.filter(RegistrationEnd='2008').count()
            dependent_values_1.append(y2008)

            y2009 = student.objects.filter(RegistrationEnd='2009').count()
            dependent_values_1.append(y2009)
            y2010 = student.objects.filter(RegistrationEnd='2010').count()
            dependent_values_1.append(y2010)

            y2011 = student.objects.filter(RegistrationEnd='2011').count()
            dependent_values_1.append(y2011)

            y2012 = student.objects.filter(RegistrationEnd='2012').count()
            dependent_values_1.append(y2012)

            y2013 = student.objects.filter(RegistrationEnd='2013').count()
            dependent_values_1.append(y2013)

            y2014 = student.objects.filter(RegistrationEnd='2014').count()
            dependent_values_1.append(y2014)

            y2015 = student.objects.filter(RegistrationEnd='2015').count()
            dependent_values_1.append(y2015)

            y2016 = student.objects.filter(RegistrationEnd='2016').count()
            dependent_values_1.append(y2016)

            y2017 = student.objects.filter(RegistrationEnd='2017').count()
            dependent_values_1.append(y2017)

            y2018 = student.objects.filter(RegistrationEnd='2018').count()
            dependent_values_1.append(y2018)

        elif dependent_extra_variable == 'YearStarted':
            y2008 = student.objects.filter(YearStarted='2008').count()
            dependent_values_1.append(y2008)

            y2009 = student.objects.filter(YearStarted='2009').count()
            dependent_values_1.append(y2009)

            y2010 = student.objects.filter(YearStarted='2010').count()
            dependent_values_1.append(y2010)

            y2011 = student.objects.filter(YearStarted='2011').count()
            dependent_values_1.append(y2011)

            y2012 = student.objects.filter(YearStarted='2012').count()
            dependent_values_1.append(y2012)

            y2013 = student.objects.filter(YearStarted='2013').count()
            dependent_values_1.append(y2013)

            y2014 = student.objects.filter(YearStarted='2014').count()
            dependent_values_1.append(y2014)

            y2015 = student.objects.filter(YearStarted='2015').count()
            dependent_values_1.append(y2015)

            y2016 = student.objects.filter(YearStarted='2016').count()
            dependent_values_1.append(y2016)

            y2017 = student.objects.filter(YearStarted='2017').count()
            dependent_values_1.append(y2017)

            y2018 = student.objects.filter(YearStarted='2018').count()
            dependent_values_1.append(y2018)
        graphinfo ={
        "independent_values":independent_values,
        "dependent_values":dependent_values,
        "dependent_extra_values":dependent_values_1,
        "graph_type":graph_type,
        "colours":colour_value
        }



        return JsonResponse(graphinfo)





def home_view(request, *args, **kwargs):
    return render(request, "home.html", {})  # templates


def abc(request, *args, **kwargs):
    form =  GenerateGraphForm()
    return render(request, "abc.html", {'form':form})  # templates


def register_view(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, f'Your account has been created! You are now able to log in')
            return redirect('login')
    else:

        form = UserRegisterForm()
    return render(request, 'register.html', {'form': form})
