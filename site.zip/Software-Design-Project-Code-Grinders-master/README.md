
[![Coverage Status](https://coveralls.io/repos/github/rinae-hub/Software-Design-Project-Code-Grinders/badge.svg?branch=master&service=github)](https://coveralls.io/github/rinae-hub/Software-Design-Project-Code-Grinders?branch=master)


[![Build Status](https://travis-ci.org/rinae-hub/Software-Design-Project-Code-Grinders.svg?branch=master)](https://travis-ci.org/rinae-hub/Software-Design-Project-Code-Grinders) 


